from distutils.core import setup,Extension

setup(name="Buslist",
      version='1.0',
      py_modules=['BuslinePr'])
